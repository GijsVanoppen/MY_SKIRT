---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: petercamps

---

**Description**
A clear description of what you want to happen.

**Alternatives**
A description of any alternative solutions or features you've considered.

**Context**
Add any other context about the feature request here.
