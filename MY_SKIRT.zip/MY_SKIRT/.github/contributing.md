**Contributing to the SKIRT project**

Thank you for reading this and for considering a contribution to the SKIRT project.

A contribution can take many forms: asking a question, reporting a bug, suggesting a new
feature, correcting or improving the documentation, writing a tutorial, fixing a bug, 
implementing a new class or a new module, and so on.

Information on how to contribute can be found in the "Contributing" section of the
SKIRT project web site: http://www.skirt.ugent.be/root/_contributing.html

The core SKIRT team.
